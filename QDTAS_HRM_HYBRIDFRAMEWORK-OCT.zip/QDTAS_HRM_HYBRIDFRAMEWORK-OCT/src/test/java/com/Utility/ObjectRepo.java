package com.Utility;

import com.aventstack.extentreports.ExtentTest;

public class ObjectRepo {

	public static ExtentTest test;   //predefined class
	
}
